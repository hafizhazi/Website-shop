// Fungsi untuk menambahkan produk ke keranjang
function addToCart(productName, price) {
    alert(`Produk ${productName} dengan harga Rp${price.toLocaleString()} telah ditambahkan ke keranjang!`);
}